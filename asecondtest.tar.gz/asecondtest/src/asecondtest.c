#include<stdio.h>
int a =8,b=9,sum=0;
int main()
{
	printf("value of a is:%d\r\n",a);
	sum=a+b;
	printf("sum of a and b is :%d\r\n",sum);
	return 0;
}
