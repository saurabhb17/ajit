#include<stdio.h>

int main()
{
	puts("Hi world\r\n");
	printf("hello world\r\n");
	return 0;
}
