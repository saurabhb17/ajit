#include<stdio.h>

void main()
{
	puts("Hi world\r\n");
	printf("hello world\r\n");
}
