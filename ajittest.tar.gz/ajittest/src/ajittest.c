#include<stdio.h>
int a =8;
int main()
{
	printf("Hi world:%d\r\n",a);
	a++;
	printf("hello world:%d\r\n",a);
	return 0;
}
